exports.submitComplaint = (req, res) => {
  const { title, description, category } = req.body;
  const userId = req.user.id;
  const query = 'INSERT INTO complaints (user_id, title, description, category) VALUES (?, ?, ?, ?)';
  db.query(query, [userId, title, description, category], (err, result) => {
    if (err) return res.status(500).send('Server error');
    res.status(201).send('Complaint submitted');
  });
};
exports.getComplaints = (req, res) => {
  const userId = req.user.id;
  const query = 'SELECT * FROM complaints WHERE user_id = ?';
  db.query(query, [userId], (err, result) => {
    if (err) return res.status(500).send('Server error');
    res.json(result);
  });
};
