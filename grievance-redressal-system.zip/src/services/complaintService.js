import axios from 'axios';
const API_URL = 'http://localhost:5000/api';
export const submitComplaint = (complaintData, token) => axios.post(`${API_URL}/complaint`, complaintData, {
  headers: { Authorization: `Bearer ${token}` },
});
export const getComplaints = (token) => axios.get(`${API_URL}/complaints`, {
  headers: { Authorization: `Bearer ${token}` },
});
