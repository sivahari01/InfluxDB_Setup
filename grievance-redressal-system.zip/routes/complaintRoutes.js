const express = require('express');
const { submitComplaint, getComplaints } = require('../controllers/complaintController');
const { authMiddleware } = require('../middleware/authMiddleware');
const router = express.Router();
router.post('/complaint', authMiddleware, submitComplaint);
router.get('/complaints', authMiddleware, getComplaints);
module.exports = router;
